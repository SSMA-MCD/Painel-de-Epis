# Book Fornecedores SSMA — Fotos indexadas (versão simplificada)

## O que tem aqui

- **imagens/** — as 170 fotos, todas numa pasta só, nomeadas como `<fornecedor>_<código>.png`
  (ex: `abastece_17165.png`, `ecolab_46711409.png`, `treinnar_MR83452457.png`, `book-de-epis_M032803.png`)
- **index_fotos.csv** / **index_fotos.json** — tabela com código, descrição, arquivo e confiança da correspondência

## Como subir no GitHub (2 passos)

1. No repositório, clique em **Add file → Create new file**, digite `imagens/.gitkeep` no nome e clique em **Commit changes**. Isso cria a pasta.
2. Entre na pasta `imagens` que acabou de aparecer → **Add file → Upload files** → clique em "choose your files" → selecione TODOS os arquivos da pasta `imagens` deste zip (Ctrl+A) → **Commit changes**.

Depois suba os dois arquivos `index_fotos.csv` e `index_fotos.json` direto na raiz do repositório (Add file → Upload files → choose your files).

## Sobre a confiança de cada correspondência

- **alta** (≥75%): pode confiar e usar direto.
- **media** (55–74%): provavelmente certo, mas vale um olhar rápido.
- **baixa-revisar** (<55%): principalmente em `book-de-epis` (20 itens) — nomes de EPIs muito parecidos confundiram o OCR. Confira na `review.html` enviada antes.

## Sem foto no material enviado

GLASS POINT NEW (21 itens) e TJ PRINT (9 itens) não têm nenhuma foto. TREINNAR tem 65 de 84 itens com foto; BOOK DE EPIS tem 48 de ~159.
